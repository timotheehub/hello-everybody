package org.jivesoftware.smackx.entitycaps;

public interface CapsVerListener {
    public void capsVerUpdated(String capsVer);
}
